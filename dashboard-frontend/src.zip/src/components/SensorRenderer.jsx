// src/components/SensorRenderer.jsx
import React, { useState } from "react";
import HistoryModal from "./HistoryModal";
import {
  Thermometer, Droplets, Gauge, Sun, Ruler, Waves,
  Activity, Zap, RotateCw, Eye, Move3d, Wind, CircleDot
} from "lucide-react";

const API_BASE = import.meta.env?.VITE_API_BASE || "";

const SENSOR_ICONS = {
  temperature: Thermometer,
  humidity: Droplets,
  pressure: Gauge,
  light_intensity: Sun,
  ultrasonic: Ruler,
  infrared: Eye,
  imu: Move3d,
  voltage: Zap,
  rotary_encoder: RotateCw,
  rotary_sensor: RotateCw,
  encoder: RotateCw,
  current: Zap,
  distance: Ruler,
  motion: Waves,
  sound: Waves,
  gas: Wind,
  flame: CircleDot,
  vibration: Activity,
  us: Ruler,
};

const SENSOR_COLORS = {
  temperature: { icon: 'text-orange-500', bg: 'bg-orange-500/10', border: 'border-orange-500/20' },
  humidity: { icon: 'text-blue-500', bg: 'bg-blue-500/10', border: 'border-blue-500/20' },
  pressure: { icon: 'text-purple-500', bg: 'bg-purple-500/10', border: 'border-purple-500/20' },
  light_intensity: { icon: 'text-yellow-500', bg: 'bg-yellow-500/10', border: 'border-yellow-500/20' },
  ultrasonic: { icon: 'text-cyan-500', bg: 'bg-cyan-500/10', border: 'border-cyan-500/20' },
  us: { icon: 'text-cyan-500', bg: 'bg-cyan-500/10', border: 'border-cyan-500/20' },
  infrared: { icon: 'text-red-500', bg: 'bg-red-500/10', border: 'border-red-500/20' },
  imu: { icon: 'text-indigo-500', bg: 'bg-indigo-500/10', border: 'border-indigo-500/20' },
  voltage: { icon: 'text-green-500', bg: 'bg-green-500/10', border: 'border-green-500/20' },
  current: { icon: 'text-emerald-500', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20' },
  rotary_encoder: { icon: 'text-teal-500', bg: 'bg-teal-500/10', border: 'border-teal-500/20' },
  rotary_sensor: { icon: 'text-teal-500', bg: 'bg-teal-500/10', border: 'border-teal-500/20' },
  encoder: { icon: 'text-teal-500', bg: 'bg-teal-500/10', border: 'border-teal-500/20' },
  vibration: { icon: 'text-pink-500', bg: 'bg-pink-500/10', border: 'border-pink-500/20' },
  default: { icon: 'text-gray-500', bg: 'bg-gray-500/10', border: 'border-gray-500/20' },
};

export default function SensorRenderer({
  node,
  hubId,
  raspiId,
  viewMode = 'grid',
  onReset,
}) {
  const [resetting, setResetting] = useState(false);
  const [openModal, setOpenModal] = useState(false);
  const portId = Number(String(node?.node_id || "").replace(/^P/i, "")) || null;

  const sensorType = String(node.sensor_type || 'unknown').toLowerCase();
  const IconComponent = SENSOR_ICONS[sensorType] || Activity;
  const colors = SENSOR_COLORS[sensorType] || SENSOR_COLORS.default;

  async function handleReset(e) {
    e.stopPropagation();
    if (!raspiId || !hubId || !portId) {
      alert("Parameter reset tidak lengkap (raspiId / hubId / portId).");
      return;
    }
    const ok = confirm(
      `Reset data untuk ${hubId} • Port ${portId}?\nSemua histori di port ini akan dihapus dan sensor_id baru akan dibuat.`
    );
    if (!ok) return;

    try {
      setResetting(true);
      const res = await fetch(`${API_BASE}/api/reset-port`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ raspi_serial_id: raspiId, hub_id: hubId, port_id: portId }),
      });

      let data = null;
      try { data = await res.json(); } catch { }

      if (!res.ok || !data?.success) {
        const msg = data?.error || data?.message || "Reset gagal.";
        alert(msg);
        return;
      }
      alert(`Reset berhasil. SensorID baru: ${data.newSensorId}`);
      onReset && onReset({ hubId, portId, newSensorId: data.newSensorId });
    } catch (e) {
      console.error(e);
      alert("Gagal terhubung ke server.");
    } finally {
      setResetting(false);
    }
  }

  // ========== HELPER: Get reading by key ==========
  const getReading = (key) => {
    if (!node.readings || !Array.isArray(node.readings)) return null;
    return node.readings.find(r => r.key === key);
  };

  const formatValue = () => {
    const val = node.value;
    const rawData = node._raw_data;
    const readings = node.readings;

    // ========== HUMIDITY SENSOR (NEW FORMAT) ==========
    if (sensorType === 'humidity' && readings) {
      const tempReading = getReading('temperature');
      const humidityReading = getReading('humidity');

      return (
        <div className="space-y-3">
          {/* Primary: Humidity */}
          {humidityReading && (
            <div>
              <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">
                {humidityReading.value.toFixed(1)}
                <span className="text-lg ml-1">{humidityReading.unit}</span>
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400 uppercase tracking-wide font-medium">
                {humidityReading.label}
              </div>
            </div>
          )}

          {/* Secondary: Temperature */}
          {tempReading && (
            <div className="pt-2 border-t border-black/10 dark:border-white/10">
              <div className="flex items-center gap-2">
                <Thermometer className="w-4 h-4 text-orange-500 flex-shrink-0" />
                <div className="flex items-baseline gap-2">
                  <span className="text-lg font-semibold text-slate-900 dark:text-white">
                    {tempReading.value.toFixed(1)}{tempReading.unit}
                  </span>
                  <span className="text-xs text-gray-600 dark:text-gray-400">
                    {tempReading.label}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      );
    }

    // ========== HUMIDITY SENSOR (OLD FORMAT - BACKWARD COMPATIBILITY) ==========
    if (sensorType === 'humidity' && rawData) {
      return (
        <div className="space-y-3">
          <div>
            <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">
              {rawData.humidity?.toFixed(1) || val}
              <span className="text-lg ml-1">%</span>
            </div>
            <div className="text-xs text-gray-600 dark:text-gray-400 uppercase tracking-wide font-medium">
              Humidity
            </div>
          </div>

          {rawData.temperature !== undefined && (
            <div className="pt-2 border-t border-black/10 dark:border-white/10">
              <div className="flex items-center gap-2">
                <Thermometer className="w-4 h-4 text-orange-500 flex-shrink-0" />
                <div className="flex items-baseline gap-2">
                  <span className="text-lg font-semibold text-slate-900 dark:text-white">
                    {rawData.temperature.toFixed(1)}°C
                  </span>
                  <span className="text-xs text-gray-600 dark:text-gray-400">
                    Temperature
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      );
    }

    // ========== IMU SENSOR ==========
    if (sensorType === 'imu' && rawData) {
      const acc = rawData.accelerometer || {};
      const gyro = rawData.gyroscope || {};
      const temp = rawData.temperature;

      return (
        <div className="space-y-2 text-xs">
          <div>
            <div className="font-semibold text-gray-700 dark:text-gray-300">Accelerometer (m/s²)</div>
            <div className="font-mono">
              X:{Number(acc.x || 0).toFixed(2)} Y:{Number(acc.y || 0).toFixed(2)} Z:{Number(acc.z || 0).toFixed(2)}
            </div>
          </div>
          <div>
            <div className="font-semibold text-gray-700 dark:text-gray-300">Gyroscope (rad/s)</div>
            <div className="font-mono">
              X:{Number(gyro.x || 0).toFixed(2)} Y:{Number(gyro.y || 0).toFixed(2)} Z:{Number(gyro.z || 0).toFixed(2)}
            </div>
          </div>
          {temp && (
            <div className="text-gray-600 dark:text-gray-400">
              Temp: {Number(temp).toFixed(1)}°C
            </div>
          )}
        </div>
      );
    }

    // ========== ROTARY ENCODER ==========
    if ((sensorType === 'rotary_encoder' || sensorType === 'rotary_sensor') && rawData) {
      return (
        <div className="space-y-1">
          <div className="text-2xl font-bold">{rawData.direction || 'CW'}</div>
          <div className="text-sm text-gray-600 dark:text-gray-400">
            Count: {rawData.count || 0}
          </div>
        </div>
      );
    }

    // ========== VIBRATION ==========
    if (sensorType === 'vibration' && rawData) {
      const detected = rawData.detected;
      return (
        <div className={`text-lg font-semibold ${detected ? 'text-red-600 dark:text-red-400' : 'text-gray-600 dark:text-gray-400'}`}>
          {detected ? 'DETECTED' : 'CLEAR'}
        </div>
      );
    }

    // ========== VOLTAGE / CURRENT ==========
    if ((sensorType === 'voltage' || sensorType === 'current') && rawData) {
      const value = sensorType === 'voltage' ? rawData.voltage : rawData.current;
      const unit = sensorType === 'voltage' ? 'V' : 'A';
      return (
        <div>
          <span className="text-2xl font-bold">{Number(value).toFixed(2)}</span>
          <span className="text-base ml-1 text-gray-600 dark:text-gray-400">{unit}</span>
        </div>
      );
    }

    // ========== ULTRASONIC ==========
    if ((sensorType === 'ultrasonic' || sensorType === 'us') && rawData) {
      return (
        <div>
          <span className="text-2xl font-bold">{Number(rawData.distance).toFixed(2)}</span>
          <span className="text-base ml-1 text-gray-600 dark:text-gray-400">cm</span>
        </div>
      );
    }

    // ========== FALLBACK: Use readings array if available ==========
    if (readings && readings.length > 0) {
      return (
        <div className="space-y-2">
          {readings.map((reading, idx) => (
            <div key={idx}>
              <div className="text-2xl font-bold text-slate-900 dark:text-white">
                {reading.value.toFixed(2)}
                <span className="text-base ml-1 text-gray-600 dark:text-gray-400">
                  {reading.unit}
                </span>
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">
                {reading.label}
              </div>
            </div>
          ))}
        </div>
      );
    }

    // ========== FALLBACK: NUMERIC ==========
    if (typeof val === 'number') {
      return (
        <>
          {val.toFixed(2)}
          {node.unit && <span className="text-base ml-1 text-gray-600 dark:text-gray-400">{node.unit}</span>}
        </>
      );
    }

    // ========== FALLBACK: STRING ==========
    return (
      <>
        {val}
        {node.unit && <span className="text-base ml-1 text-gray-600 dark:text-gray-400">{node.unit}</span>}
      </>
    );
  };

  // ========== LIST VIEW ==========
  if (viewMode === 'list') {
    return (
      <>
        <div
          role="button"
          onClick={() => setOpenModal(true)}
          className={`rounded-lg border ${colors.border} ${colors.bg} p-4 hover:bg-opacity-80 
                     transition-all cursor-pointer flex items-center justify-between`}
        >
          <div className="flex items-center gap-4 flex-1">
            <div className={`p-3 rounded-lg ${colors.bg} flex-shrink-0`}>
              <IconComponent className={`w-6 h-6 ${colors.icon}`} />
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">
                {node.node_id} • <span className="capitalize">{node.sensor_type.replace('_', ' ')}</span>
              </div>
              
              {/* HUMIDITY in List View */}
              {sensorType === 'humidity' && node.readings ? (
                <div className="flex items-center gap-4">
                  {getReading('humidity') && (
                    <div>
                      <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                        {getReading('humidity').value.toFixed(1)}{getReading('humidity').unit}
                      </span>
                      <span className="text-xs text-gray-600 dark:text-gray-400 ml-2">
                        {getReading('humidity').label}
                      </span>
                    </div>
                  )}
                  {getReading('temperature') && (
                    <>
                      <div className="text-gray-400">•</div>
                      <div className="flex items-center gap-1">
                        <Thermometer className="w-4 h-4 text-orange-500" />
                        <span className="text-lg font-semibold text-slate-900 dark:text-white">
                          {getReading('temperature').value.toFixed(1)}{getReading('temperature').unit}
                        </span>
                      </div>
                    </>
                  )}
                </div>
              ) : (
                <div className="text-lg font-semibold text-slate-900 dark:text-white">
                  {formatValue()}
                </div>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-3 flex-shrink-0">
            <div className={`text-xs font-medium px-3 py-1 rounded-full ${
              node.status === 'online' 
                ? 'bg-green-500/20 text-green-600 dark:text-green-400' 
                : 'bg-gray-500/20 text-gray-600 dark:text-gray-400'
            }`}>
              {node.status}
            </div>
            <button
              type="button"
              onClick={handleReset}
              disabled={resetting}
              className={`text-xs rounded-md border px-3 py-1.5 
                ${resetting
                  ? "opacity-60 cursor-not-allowed"
                  : "hover:bg-black/5 dark:hover:bg-white/10"}
                border-black/10 dark:border-white/10 text-gray-700 dark:text-gray-200`}
              title="Reset histori port ini"
            >
              {resetting ? "..." : "Reset"}
            </button>
          </div>
        </div>
        
        <HistoryModal
          open={openModal}
          onClose={() => setOpenModal(false)}
          raspiId={raspiId}
          hubId={hubId}
          portId={portId}
          sensorTypeHint={node.sensor_type}
        />
      </>
    );
  }

  // ========== GRID VIEW ==========
  return (
    <>
      <div
        role="button"
        onClick={() => setOpenModal(true)}
        className={`rounded-xl border ${colors.border} ${colors.bg} p-4 
                   hover:border-opacity-40 transition-all cursor-pointer group`}
      >
        <div className="flex items-center justify-between mb-3">
          <div className={`p-2 rounded-lg ${colors.bg} group-hover:scale-110 transition-transform`}>
            <IconComponent className={`w-5 h-5 ${colors.icon}`} />
          </div>
          <div className="flex items-center gap-2">
            <div className={`text-xs font-medium px-2 py-1 rounded-full ${
              node.status === 'online'
                ? 'bg-green-500/20 text-green-600 dark:text-green-400'
                : 'bg-gray-500/20 text-gray-600 dark:text-gray-400'
            }`}>
              {node.status}
            </div>
            <button
              type="button"
              onClick={handleReset}
              disabled={resetting}
              className={`text-[10px] rounded-md border px-2 py-1 
                ${resetting
                  ? "opacity-60 cursor-not-allowed"
                  : "hover:bg-black/5 dark:hover:bg-white/10"}
                border-black/10 dark:border-white/10 text-gray-700 dark:text-gray-200`}
              title="Reset histori port ini"
            >
              {resetting ? "..." : "Reset"}
            </button>
          </div>
        </div>

        <div className="mb-2">
          <div className="text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">
            {node.node_id}
          </div>
          <div className="text-sm text-gray-700 dark:text-gray-300 capitalize">
            {node.sensor_type.replace('_', ' ')}
          </div>
        </div>

        <div className="text-slate-900 dark:text-white min-h-[100px]">
          {formatValue()}
        </div>

        <div className="mt-3 text-[10px] text-gray-500 dark:text-gray-400 flex items-center gap-1">
          <Eye className="w-3 h-3" />
          <span>Click to view history</span>
        </div>
      </div>

      <HistoryModal
        open={openModal}
        onClose={() => setOpenModal(false)}
        raspiId={raspiId}
        hubId={hubId}
        portId={portId}
        sensorTypeHint={node.sensor_type}
      />
    </>
  );
}