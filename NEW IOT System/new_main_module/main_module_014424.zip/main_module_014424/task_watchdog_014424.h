#pragma once
#include <Arduino.h>
#include "ciren_config_014424.h"
#include "ring_buffer_014424.h"
#include "system_state_014424.h"

void task_watchdog(void* param) {
  for (;;) {
    vTaskDelay(pdMS_TO_TICKS(WD_CHECK_MS));
    float usage = rb_usage();
    if (usage > RB_WARN_THRESHOLD)
      Serial.printf("[WD] Ring buffer %.0f%% full\n", usage * 100);
    xSemaphoreTake(state_mutex, portMAX_DELAY);
    uint16_t errs = sys_state.err_counter;
    if (errs > 50) sys_state.err_counter = 0;
    xSemaphoreGive(state_mutex);
    Serial.printf("[WD] rb=%.0f%% err=%d connected=%s uptime=%lus\n",
      usage * 100, errs, state_is_connected() ? "yes" : "no", millis() / 1000);
  }
}
