#pragma once
#include <esp_now.h>
#include "ciren_config_014424.h"
#include "ring_buffer_014424.h"
#include "system_state_014424.h"

typedef struct {
  uint8_t type;
  uint8_t channel;
} __attribute__((packed)) HelloAck;

static void espnow_recv_cb(const uint8_t* mac, const uint8_t* data, int len) {
  if (len != sizeof(SensorPacket)) return;

  SensorPacket pkt;
  memcpy(&pkt, data, sizeof(pkt));

  // ── HELLO dari sensor controller ────────────────────────────────────────
  if (pkt.ftype == FTYPE_HELLO) {

    uint8_t ch = (uint8_t)WiFi.channel();

    // Jangan reply channel=0 — WiFi belum associate
    if (ch == 0) {
      Serial.printf("[HELLO_ACK] skip — WiFi ch=0 (ctrl_id=%d)\n", pkt.ctrl_id);
      return;
    }

    // Tambah peer kalau belum ada, update channel kalau sudah ada
    if (!esp_now_is_peer_exist(mac)) {
      esp_now_peer_info_t peer = {};
      memcpy(peer.peer_addr, mac, 6);
      peer.channel = ch;
      peer.encrypt = false;
      if (esp_now_add_peer(&peer) != ESP_OK) {
        Serial.println("[ESPNOW] add_peer failed");
        return;
      }
    } else {
      // Update channel peer setiap HELLO masuk (handle main module reboot)
      esp_now_peer_info_t peer = {};
      memcpy(peer.peer_addr, mac, 6);
      peer.channel = ch;
      peer.encrypt = false;
      esp_now_mod_peer(&peer);
    }

    // Kirim HELLO_ACK dengan channel WiFi aktif
    HelloAck ack;
    ack.type    = 0xAC;
    ack.channel = ch;
    esp_now_send((uint8_t*)mac, (uint8_t*)&ack, sizeof(ack));

    // FIX Bug 1: gunakan esp_now_peer_num_t struct, bukan NULL
    esp_now_peer_num_t peer_num = {};
    if (esp_now_get_peer_num(&peer_num) == ESP_OK) {
      xSemaphoreTake(state_mutex, portMAX_DELAY);
      sys_state.peer_count = peer_num.total_num;
      xSemaphoreGive(state_mutex);
    }

    Serial.printf("[HELLO_ACK] ctrl_id=%d ch=%d peers=%d\n",
                  pkt.ctrl_id, ch, peer_num.total_num);
    return;
  }

  // ── ERROR frame ─────────────────────────────────────────────────────────
  if (pkt.ftype == FTYPE_ERROR) {
    xSemaphoreTake(state_mutex, portMAX_DELAY);
    sys_state.err_counter++;
    xSemaphoreGive(state_mutex);
    return;
  }

  // ── Data / heartbeat — masukkan ke ring buffer ───────────────────────────
  rb_write(&pkt);
  Serial.printf("[RX] ctrl=%d port=%d stype=0x%02X val=%.4f ftype=0x%02X\n",
                pkt.ctrl_id, pkt.port_num, pkt.sensor_type,
                pkt.value, pkt.ftype);
}

// esp_now_init() dan register_recv_cb dipanggil dari setup(),
// task ini hanya jalan idle — callback handle data secara async
void task_espnow_rx(void* param) {
  for (;;) vTaskDelay(portMAX_DELAY);
}