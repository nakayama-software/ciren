#pragma once

#define DEVICE_ID          "MM-001"
#define FW_VERSION         "1.0.0"

#define PIN_OLED_SDA       8
#define PIN_OLED_SCL       9
#define PIN_BTN            18

#define OLED_ADDR          0x3C
#define OLED_WIDTH         128
#define OLED_HEIGHT        64

#define PIN_MODEM_RX       16
#define PIN_MODEM_TX       17
#define MODEM_BAUD         115200

#define RB_SIZE            128
#define AGG_WINDOW_MS      50

#define WIFI_TIMEOUT_MS    15000
#define WIFI_COOLDOWN_MS   20000
#define RECONNECT_DELAY_1  1000
#define RECONNECT_DELAY_2  2000
#define RECONNECT_DELAY_3  4000

#define MQTT_PORT          1883
#define MQTT_QOS           1
#define MQTT_KEEPALIVE     60

#define BTN_HOLD_MS        5000
#define BTN_DEBOUNCE_MS    30

#define OLED_REFRESH_MS    200
#define OLED_TOTAL_PAGES   6

#define PAGE_GATEWAY       0
#define PAGE_WIFI          1
#define PAGE_SIM           2
#define PAGE_GPS           3
#define PAGE_SETTINGS      4
#define PAGE_SIM_CTRL      5

#define PORTAL_PASS        "setup1234"
#define PORTAL_PORT        80

#define GPS_POLL_MS        60000
#define GPS_STALE_MS       120000
#define SIM_BOOT_WAIT_MS   8000
#define SIM_RETRY_MS       60000
#define SIM_SIGNAL_INT_MS  15000

#define PRIO_RX            5
#define PRIO_CONN          4
#define PRIO_AGG           3
#define PRIO_PUBLISH       3
#define PRIO_GPS           3
#define PRIO_WATCHDOG      2
#define PRIO_OLED          2
#define PRIO_CONFIG        2

#define STACK_RX           4096
#define STACK_CONN         4096
#define STACK_AGG          6144
#define STACK_PUBLISH      6144
#define STACK_GPS          3072
#define STACK_WATCHDOG     2048
#define STACK_OLED         4096
#define STACK_CONFIG       3072

#define STYPE_TEMPERATURE  0x01
#define STYPE_HUMIDITY     0x02
#define STYPE_ACCEL_X      0x03
#define STYPE_ACCEL_Y      0x04
#define STYPE_ACCEL_Z      0x05
#define STYPE_GYRO_X       0x06
#define STYPE_GYRO_Y       0x07
#define STYPE_GYRO_Z       0x08
#define STYPE_DISTANCE     0x09
#define STYPE_TEMP_1WIRE   0x0A
#define STYPE_PITCH        0x10
#define STYPE_ROLL         0x11
#define STYPE_YAW          0x12

#define FTYPE_DATA         0x01
#define FTYPE_HELLO        0x02
#define FTYPE_HEARTBEAT    0x03
#define FTYPE_DATA_TYPED   0x04
#define FTYPE_HB_TYPED     0x05
#define FTYPE_ERROR        0xFF
#define FTYPE_STALE        0xFE

#define TOPIC_DATA         "ciren/data/" DEVICE_ID
#define TOPIC_STATUS       "ciren/status/" DEVICE_ID
#define TOPIC_HELLO        "ciren/hello/" DEVICE_ID
#define TOPIC_CONFIG       "ciren/config/" DEVICE_ID

#define WD_CHECK_MS        30000
#define RB_WARN_THRESHOLD  0.8f
