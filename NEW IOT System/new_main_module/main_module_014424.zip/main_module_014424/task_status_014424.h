#pragma once
#include <Arduino.h>
#include "ciren_config_014424.h"
#include "system_state_014424.h"
#include "task_publish_014424.h"

void task_status(void* param) {
  static bool hello_sent = false;
  for (;;) {
    vTaskDelay(pdMS_TO_TICKS(10000));
    if (!state_is_connected()) continue;

    PublishItem item;

    if (!hello_sent) {
      strncpy(item.topic, TOPIC_HELLO, sizeof(item.topic));
      item.len = snprintf(item.payload, PQ_MAX_PAYLOAD,
        "{\"conn_mode\":\"%s\",\"fw_version\":\"%s\"}",
        sys_state.conn_mode, FW_VERSION
      );
      xQueueSend(publish_queue, &item, 0);
      hello_sent = true;
    }

    xSemaphoreTake(state_mutex, portMAX_DELAY);
    float  lat  = sys_state.gps_lat;
    float  lon  = sys_state.gps_lon;
    bool   fix  = sys_state.gps_fix;
    int8_t rssi = sys_state.rssi;
    uint8_t batt = sys_state.batt_pct;
    xSemaphoreGive(state_mutex);

    strncpy(item.topic, TOPIC_STATUS, sizeof(item.topic));
    item.len = snprintf(item.payload, PQ_MAX_PAYLOAD,
      "{\"conn_mode\":\"%s\","
      "\"gps_lat\":%.6f,\"gps_lon\":%.6f,\"gps_fix\":%s,"
      "\"rssi\":%d,\"batt_pct\":%d,\"fw_version\":\"%s\"}",
      sys_state.conn_mode, lat, lon, fix ? "true" : "false",
      rssi, batt, FW_VERSION
    );
    xQueueSend(publish_queue, &item, 0);
  }
}
